package moscow.rockstar.systems.modules.modules.visuals;

import moscow.rockstar.systems.event.EventListener;
import moscow.rockstar.systems.event.impl.game.GameTickEvent;
import moscow.rockstar.systems.modules.api.ModuleCategory;
import moscow.rockstar.systems.modules.api.ModuleInfo;
import moscow.rockstar.systems.modules.impl.BaseModule;
import moscow.rockstar.systems.setting.settings.ModeSetting;
import moscow.rockstar.systems.setting.settings.SliderSetting;

@ModuleInfo(name = "Custom Weather", category = ModuleCategory.VISUALS, desc = "Кастомная погода (ясно, дождь, гроза)")
public class CustomWeather extends BaseModule {

    private final ModeSetting weather = new ModeSetting(this, "modules.settings.custom_weather.type");
    private final ModeSetting.Value clear = new ModeSetting.Value(this.weather, "Clear").select();
    private final ModeSetting.Value rain = new ModeSetting.Value(this.weather, "Rain");
    private final ModeSetting.Value thunder = new ModeSetting.Value(this.weather, "Thunder");

    private final SliderSetting intensity = new SliderSetting(this, "modules.settings.custom_weather.intensity")
            .min(0.0F).max(1.0F).step(0.05F).currentValue(1.0F);

    private final EventListener<GameTickEvent> onTick = event -> {
        if (mc.world == null) return;

        if (clear.isSelected()) {
            mc.world.setRainGradient(0.0F);
            mc.world.setThunderGradient(0.0F);
        } else if (rain.isSelected()) {
            mc.world.setRainGradient(intensity.getCurrentValue());
            mc.world.setThunderGradient(0.0F);
        } else if (thunder.isSelected()) {
            mc.world.setRainGradient(intensity.getCurrentValue());
            mc.world.setThunderGradient(intensity.getCurrentValue());
        }
    };

    @Override
    public void onDisable() {
        if (mc.world != null) {
            mc.world.setRainGradient(0.0F);
            mc.world.setThunderGradient(0.0F);
        }
        super.onDisable();
    }
}
