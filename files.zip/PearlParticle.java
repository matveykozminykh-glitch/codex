package moscow.rockstar.systems.modules.modules.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import moscow.rockstar.Rockstar;
import moscow.rockstar.systems.event.EventListener;
import moscow.rockstar.systems.event.impl.game.GameTickEvent;
import moscow.rockstar.systems.event.impl.render.Render3DEvent;
import moscow.rockstar.systems.modules.api.ModuleCategory;
import moscow.rockstar.systems.modules.api.ModuleInfo;
import moscow.rockstar.systems.modules.impl.BaseModule;
import moscow.rockstar.systems.setting.settings.ModeSetting;
import moscow.rockstar.systems.setting.settings.SliderSetting;
import moscow.rockstar.utility.colors.ColorRGBA;
import moscow.rockstar.utility.colors.Colors;
import moscow.rockstar.utility.math.MathUtility;
import moscow.rockstar.utility.render.DrawUtility;
import moscow.rockstar.utility.render.RenderUtility;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@ModuleInfo(name = "Pearl Particle", category = ModuleCategory.VISUALS, desc = "Шлейф частиц за летящим жемчугом")
public class PearlParticle extends BaseModule {

    private final List<PearlTrailParticle> particles = new ArrayList<>();

    private final SliderSetting density = new SliderSetting(this, "modules.settings.pearl_particle.density")
            .min(1.0F).max(8.0F).step(1.0F).currentValue(3.0F);

    private final SliderSetting particleSize = new SliderSetting(this, "modules.settings.pearl_particle.size")
            .min(1.0F).max(15.0F).step(0.5F).currentValue(6.0F);

    private final SliderSetting lifetime = new SliderSetting(this, "modules.settings.pearl_particle.lifetime")
            .min(0.2F).max(3.0F).step(0.1F).currentValue(1.0F);

    private final ModeSetting texture = new ModeSetting(this, "modules.settings.pearl_particle.texture");
    private final ModeSetting.Value bloom = new ModeSetting.Value(this.texture, "Bloom").select();
    private final ModeSetting.Value star = new ModeSetting.Value(this.texture, "Star");
    private final ModeSetting.Value snowflake = new ModeSetting.Value(this.texture, "Snowflake");

    private final EventListener<GameTickEvent> onTick = event -> {
        if (mc.world == null) return;
        int cnt = (int) density.getCurrentValue();
        long life = (long) (lifetime.getCurrentValue() * 1000L);

        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof EnderPearlEntity pearl)) continue;

            Vec3d pos = pearl.getPos();
            Vec3d vel = pearl.getVelocity();

            for (int i = 0; i < cnt; i++) {
                Vec3d spawnPos = pos.add(
                        MathUtility.random(-0.08, 0.08),
                        MathUtility.random(-0.08, 0.08),
                        MathUtility.random(-0.08, 0.08)
                );
                Vec3d pVel = vel.multiply(-0.1 * MathUtility.random(0.5, 1.0)).add(
                        MathUtility.random(-0.03, 0.03),
                        MathUtility.random(-0.01, 0.05),
                        MathUtility.random(-0.03, 0.03)
                );
                particles.add(new PearlTrailParticle(spawnPos, pVel, Colors.ACCENT, life));
            }
        }
    };

    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (particles.isEmpty()) return;

        MatrixStack matrices = event.getMatrices();
        Camera camera = event.getCamera();
        Identifier tex = resolveTexture();

        RenderUtility.setupRender3D(true);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, tex);
        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        try {
            Iterator<PearlTrailParticle> it = particles.iterator();
            while (it.hasNext()) {
                PearlTrailParticle p = it.next();
                p.update();
                if (p.isDead()) { it.remove(); continue; }

                float progress = p.getProgress();
                float alpha = progress < 0.1F ? (progress / 0.1F) : (1.0F - progress);
                float size = particleSize.getCurrentValue() * 0.025F * (1.2F - progress * 0.7F);
                ColorRGBA color = p.color.withAlpha(p.color.getAlpha() * Math.max(0, alpha) * 0.9F);

                matrices.push();
                RenderUtility.prepareMatrices(matrices, p.position);
                matrices.multiply(camera.getRotation());
                DrawUtility.drawImage(matrices, builder, -size / 2.0, -size / 2.0, 0.0, size, size, color);
                matrices.pop();
            }
        } finally {
            RenderUtility.buildBuffer(builder);
            RenderSystem.setShaderTexture(0, 0);
            RenderUtility.endRender3D();
        }
    };

    private Identifier resolveTexture() {
        if (star.isSelected()) return Rockstar.id("textures/star.png");
        if (snowflake.isSelected()) return Rockstar.id("textures/snowflake.png");
        return Rockstar.id("textures/bloom.png");
    }

    @Override
    public void onDisable() {
        particles.clear();
        super.onDisable();
    }

    private static final class PearlTrailParticle {
        Vec3d position;
        Vec3d velocity;
        final ColorRGBA color;
        final long spawnTime, lifeTime;
        long lastUpdate;

        PearlTrailParticle(Vec3d pos, Vec3d vel, ColorRGBA color, long lifeTime) {
            this.position = pos; this.velocity = vel; this.color = color;
            this.lifeTime = lifeTime; this.spawnTime = System.currentTimeMillis();
            this.lastUpdate = spawnTime;
        }

        void update() {
            long now = System.currentTimeMillis();
            float d = Math.max(0.001F, (now - lastUpdate) / 50.0F);
            lastUpdate = now;
            position = position.add(velocity.x * d, velocity.y * d, velocity.z * d);
            velocity = new Vec3d(velocity.x * 0.94, velocity.y * 0.94 + 0.001 * d, velocity.z * 0.94);
        }

        float getProgress() { return MathHelper.clamp((float)(System.currentTimeMillis() - spawnTime) / (float)lifeTime, 0, 1); }
        boolean isDead() { return System.currentTimeMillis() - spawnTime >= lifeTime; }
    }
}
