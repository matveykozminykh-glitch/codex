package moscow.rockstar.systems.modules.modules.visuals;

import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import moscow.rockstar.Rockstar;
import moscow.rockstar.systems.event.EventListener;
import moscow.rockstar.systems.event.impl.game.GameTickEvent;
import moscow.rockstar.systems.event.impl.network.ReceivePacketEvent;
import moscow.rockstar.systems.event.impl.render.Render3DEvent;
import moscow.rockstar.systems.modules.api.ModuleCategory;
import moscow.rockstar.systems.modules.api.ModuleInfo;
import moscow.rockstar.systems.modules.impl.BaseModule;
import moscow.rockstar.systems.setting.settings.BooleanSetting;
import moscow.rockstar.systems.setting.settings.ColorSetting;
import moscow.rockstar.systems.setting.settings.SliderSetting;
import moscow.rockstar.utility.animation.base.Animation;
import moscow.rockstar.utility.animation.base.Easing;
import moscow.rockstar.utility.colors.ColorRGBA;
import moscow.rockstar.utility.colors.Colors;
import moscow.rockstar.utility.render.DrawUtility;
import moscow.rockstar.utility.render.RenderUtility;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@ModuleInfo(name = "Blink", category = ModuleCategory.VISUALS, desc = "Призрак игрока на месте телепортации")
public class Blink extends BaseModule {

    private final List<Ghost> ghosts = new ArrayList<>();
    private Vec3d lastPos = null;
    private static final double TELEPORT_THRESHOLD = 1.5;

    private final SliderSetting ghostLifetime = new SliderSetting(this, "modules.settings.blink.lifetime")
            .min(0.5F).max(5.0F).step(0.1F).currentValue(2.0F);
    private final SliderSetting maxGhosts = new SliderSetting(this, "modules.settings.blink.max_ghosts")
            .min(1.0F).max(10.0F).step(1.0F).currentValue(3.0F);
    private final ColorSetting ghostColor = new ColorSetting(this, "modules.settings.blink.color").color(Colors.ACCENT);
    private final BooleanSetting trailParticles = new BooleanSetting(this, "modules.settings.blink.particles").enable();
    private final SliderSetting glowSize = new SliderSetting(this, "modules.settings.blink.glow_size")
            .min(0.1F).max(3.0F).step(0.05F).currentValue(0.8F);

    private final List<TrailDot> trailDots = new ArrayList<>();

    // Detect teleport via server position packet
    private final EventListener<ReceivePacketEvent> onPacket = event -> {
        if (!(event.getPacket() instanceof PlayerPositionLookS2CPacket packet)) return;
        if (mc.player == null) return;

        Vec3d currentPos = mc.player.getPos();
        Vec3d teleportTarget = new Vec3d(packet.change().x(), packet.change().y(), packet.change().z());

        // Only spawn ghost if it's a significant movement (teleport not normal movement)
        if (lastPos != null && currentPos.distanceTo(teleportTarget) > TELEPORT_THRESHOLD) {
            if (ghosts.size() >= (int) maxGhosts.getCurrentValue()) {
                ghosts.remove(0);
            }
            ghosts.add(new Ghost(currentPos, ghostColor.getColor(), (long)(ghostLifetime.getCurrentValue() * 1000L)));

            if (trailParticles.isEnabled()) {
                spawnTrailBetween(currentPos, teleportTarget);
            }
        }
        lastPos = teleportTarget;
    };

    private void spawnTrailBetween(Vec3d from, Vec3d to) {
        double dist = from.distanceTo(to);
        int steps = (int) Math.min(20, dist * 2);
        if (steps < 2) return;
        for (int i = 0; i <= steps; i++) {
            double t = (double) i / steps;
            Vec3d pos = from.lerp(to, t).add(
                    (Math.random() - 0.5) * 0.3,
                    (Math.random() - 0.5) * 0.3,
                    (Math.random() - 0.5) * 0.3
            );
            trailDots.add(new TrailDot(pos, ghostColor.getColor(), 1500L));
        }
    }

    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (ghosts.isEmpty() && trailDots.isEmpty()) return;

        MatrixStack matrices = event.getMatrices();
        Camera camera = event.getCamera();
        Identifier bloomTex = Rockstar.id("textures/bloom.png");
        long now = System.currentTimeMillis();

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, bloomTex);
        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        // Render ghosts as large bloom orbs at old positions
        Iterator<Ghost> ghostIt = ghosts.iterator();
        while (ghostIt.hasNext()) {
            Ghost g = ghostIt.next();
            if (g.isDead()) { ghostIt.remove(); continue; }

            float progress = g.getProgress();
            float alpha = 1.0F - progress * progress;
            float size = glowSize.getCurrentValue() * (1.0F + progress * 0.5F);
            ColorRGBA c = g.color.withAlpha(g.color.getAlpha() * alpha * 0.8F);

            // Render multiple layered blooms to simulate ghostly player silhouette
            for (int layer = 0; layer < 3; layer++) {
                float layerSize = size * (0.5F + layer * 0.4F);
                float layerAlpha = alpha * (1.0F - layer * 0.25F);
                float yOff = layer * 0.4F;
                ColorRGBA layerColor = c.withAlpha(c.getAlpha() * layerAlpha * 0.5F);

                matrices.push();
                RenderUtility.prepareMatrices(matrices, g.position.add(0, yOff, 0));
                matrices.multiply(camera.getRotation());
                DrawUtility.drawImage(matrices, builder, -layerSize / 2.0, -layerSize / 2.0, 0.0, layerSize, layerSize, layerColor);
                matrices.pop();
            }
        }

        // Render trail dots
        Iterator<TrailDot> dotIt = trailDots.iterator();
        while (dotIt.hasNext()) {
            TrailDot d = dotIt.next();
            if (d.isDead()) { dotIt.remove(); continue; }

            float progress = d.getProgress();
            float alpha = 1.0F - progress;
            float size = 0.15F * (1.0F - progress * 0.5F);
            ColorRGBA c = d.color.withAlpha(d.color.getAlpha() * alpha * 0.6F);

            matrices.push();
            RenderUtility.prepareMatrices(matrices, d.position);
            matrices.multiply(camera.getRotation());
            DrawUtility.drawImage(matrices, builder, -size / 2.0, -size / 2.0, 0.0, size, size, c);
            matrices.pop();
        }

        RenderUtility.buildBuffer(builder);
        RenderSystem.setShaderTexture(0, 0);
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
    };

    @Override
    public void onEnable() {
        lastPos = mc.player != null ? mc.player.getPos() : null;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        ghosts.clear();
        trailDots.clear();
        lastPos = null;
        super.onDisable();
    }

    private static final class Ghost {
        final Vec3d position;
        final ColorRGBA color;
        final long spawnTime, lifeTime;

        Ghost(Vec3d pos, ColorRGBA color, long life) {
            position = pos; this.color = color; lifeTime = life;
            spawnTime = System.currentTimeMillis();
        }

        float getProgress() { return MathHelper.clamp((float)(System.currentTimeMillis() - spawnTime) / (float)lifeTime, 0, 1); }
        boolean isDead() { return System.currentTimeMillis() - spawnTime >= lifeTime; }
    }

    private static final class TrailDot {
        final Vec3d position;
        final ColorRGBA color;
        final long spawnTime, lifeTime;

        TrailDot(Vec3d pos, ColorRGBA color, long life) {
            position = pos; this.color = color; lifeTime = life;
            spawnTime = System.currentTimeMillis();
        }

        float getProgress() { return MathHelper.clamp((float)(System.currentTimeMillis() - spawnTime) / (float)lifeTime, 0, 1); }
        boolean isDead() { return System.currentTimeMillis() - spawnTime >= lifeTime; }
    }
}
