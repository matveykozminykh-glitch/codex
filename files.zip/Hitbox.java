package moscow.rockstar.systems.modules.modules.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import moscow.rockstar.Rockstar;
import moscow.rockstar.systems.event.EventListener;
import moscow.rockstar.systems.event.impl.render.Render3DEvent;
import moscow.rockstar.systems.modules.api.ModuleCategory;
import moscow.rockstar.systems.modules.api.ModuleInfo;
import moscow.rockstar.systems.modules.impl.BaseModule;
import moscow.rockstar.systems.setting.settings.BooleanSetting;
import moscow.rockstar.systems.setting.settings.ColorSetting;
import moscow.rockstar.systems.setting.settings.ModeSetting;
import moscow.rockstar.systems.setting.settings.SliderSetting;
import moscow.rockstar.utility.colors.ColorRGBA;
import moscow.rockstar.utility.colors.Colors;
import moscow.rockstar.utility.game.EntityUtility;
import moscow.rockstar.utility.render.RenderUtility;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

@ModuleInfo(name = "Hitbox", category = ModuleCategory.VISUALS, desc = "Хитбоксы игроков с градиентом и заливкой")
public class Hitbox extends BaseModule {

    private final ModeSetting style = new ModeSetting(this, "modules.settings.hitbox.style");
    private final ModeSetting.Value outline = new ModeSetting.Value(this.style, "Outline").select();
    private final ModeSetting.Value filled = new ModeSetting.Value(this.style, "Filled");
    private final ModeSetting.Value both = new ModeSetting.Value(this.style, "Both");

    private final ColorSetting primaryColor = new ColorSetting(this, "modules.settings.hitbox.color").color(Colors.ACCENT);
    private final BooleanSetting gradientFill = new BooleanSetting(this, "modules.settings.hitbox.gradient").enable();
    private final SliderSetting fillAlpha = new SliderSetting(this, "modules.settings.hitbox.fill_alpha")
            .min(0.0F).max(1.0F).step(0.01F).currentValue(0.15F);
    private final SliderSetting lineWidth = new SliderSetting(this, "modules.settings.hitbox.line_width")
            .min(0.5F).max(4.0F).step(0.1F).currentValue(1.5F);
    private final BooleanSetting onlyEnemies = new BooleanSetting(this, "modules.settings.hitbox.only_enemies");
    private final BooleanSetting pulsing = new BooleanSetting(this, "modules.settings.hitbox.pulsing");
    private final SliderSetting expandAmount = new SliderSetting(this, "modules.settings.hitbox.expand")
            .min(0.0F).max(0.5F).step(0.01F).currentValue(0.0F);

    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (!EntityUtility.isInGame()) return;

        Camera camera = event.getCamera();
        Matrix4f matrix = event.getMatrices().peek().getPositionMatrix();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();

        float tickDelta = event.getTickDelta();

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player) continue;
            if (!player.isAlive()) continue;
            if (onlyEnemies.isEnabled() && Rockstar.getInstance().getFriendManager().isFriend(player.getName().getString())) continue;

            Box box = getInterpolatedBox(player, tickDelta);
            if (expandAmount.getCurrentValue() > 0) box = box.expand(expandAmount.getCurrentValue());
            Box relBox = VisualRenderHelper.relative(box, camera);

            ColorRGBA color = primaryColor.getColor();
            if (pulsing.isEnabled()) {
                float pulse = 0.7F + 0.3F * MathHelper.sin((float)(System.currentTimeMillis() * 0.003));
                color = color.withAlpha(color.getAlpha() * pulse);
            }

            // Filled
            if (filled.isSelected() || both.isSelected()) {
                RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
                BufferBuilder fillBuilder = RenderSystem.renderThreadTesselator().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
                if (gradientFill.isEnabled()) {
                    drawGradientBox(matrix, fillBuilder, relBox, color);
                } else {
                    VisualRenderHelper.fillBox(matrix, fillBuilder, relBox, color.withAlpha(color.getAlpha() * fillAlpha.getCurrentValue()));
                }
                RenderUtility.buildBuffer(fillBuilder);
            }

            // Outline
            if (outline.isSelected() || both.isSelected()) {
                RenderSystem.lineWidth(lineWidth.getCurrentValue());
                RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
                BufferBuilder lineBuilder = RenderSystem.renderThreadTesselator().begin(DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
                VisualRenderHelper.outlineBox(matrix, lineBuilder, relBox, color, false, 1.0F);
                RenderUtility.buildBuffer(lineBuilder);
                RenderSystem.lineWidth(1.0F);
            }
        }

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    };

    private void drawGradientBox(Matrix4f matrix, BufferBuilder builder, Box box, ColorRGBA color) {
        float alpha = fillAlpha.getCurrentValue();
        ColorRGBA bottom = color.withAlpha(color.getAlpha() * alpha * 0.2F);
        ColorRGBA top = color.withAlpha(color.getAlpha() * alpha);

        // Side faces with gradient bottom -> top
        gradientQuad(matrix, builder, box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.minZ, bottom, top, true);
        gradientQuad(matrix, builder, box.minX, box.minY, box.maxZ, box.maxX, box.maxY, box.maxZ, bottom, top, true);
        gradientQuad(matrix, builder, box.minX, box.minY, box.minZ, box.minX, box.maxY, box.maxZ, bottom, top, false);
        gradientQuad(matrix, builder, box.maxX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ, bottom, top, false);
        // Top face
        builder.vertex(matrix, (float)box.minX, (float)box.maxY, (float)box.minZ).color(top.getRGB());
        builder.vertex(matrix, (float)box.maxX, (float)box.maxY, (float)box.minZ).color(top.getRGB());
        builder.vertex(matrix, (float)box.maxX, (float)box.maxY, (float)box.maxZ).color(top.getRGB());
        builder.vertex(matrix, (float)box.minX, (float)box.maxY, (float)box.maxZ).color(top.getRGB());
        // Bottom face
        builder.vertex(matrix, (float)box.minX, (float)box.minY, (float)box.minZ).color(bottom.getRGB());
        builder.vertex(matrix, (float)box.maxX, (float)box.minY, (float)box.minZ).color(bottom.getRGB());
        builder.vertex(matrix, (float)box.maxX, (float)box.minY, (float)box.maxZ).color(bottom.getRGB());
        builder.vertex(matrix, (float)box.minX, (float)box.minY, (float)box.maxZ).color(bottom.getRGB());
    }

    private void gradientQuad(Matrix4f m, BufferBuilder b, double x1, double y1, double z1, double x2, double y2, double z2, ColorRGBA colBot, ColorRGBA colTop, boolean xAxis) {
        if (xAxis) {
            b.vertex(m, (float)x1, (float)y1, (float)z1).color(colBot.getRGB());
            b.vertex(m, (float)x2, (float)y1, (float)z1).color(colBot.getRGB());
            b.vertex(m, (float)x2, (float)y2, (float)z1).color(colTop.getRGB());
            b.vertex(m, (float)x1, (float)y2, (float)z1).color(colTop.getRGB());
        } else {
            b.vertex(m, (float)x1, (float)y1, (float)z1).color(colBot.getRGB());
            b.vertex(m, (float)x1, (float)y1, (float)z2).color(colBot.getRGB());
            b.vertex(m, (float)x1, (float)y2, (float)z2).color(colTop.getRGB());
            b.vertex(m, (float)x1, (float)y2, (float)z1).color(colTop.getRGB());
        }
    }

    private Box getInterpolatedBox(PlayerEntity player, float tickDelta) {
        double x = MathHelper.lerp(tickDelta, player.prevX, player.getX());
        double y = MathHelper.lerp(tickDelta, player.prevY, player.getY());
        double z = MathHelper.lerp(tickDelta, player.prevZ, player.getZ());
        double hw = player.getWidth() / 2.0;
        return new Box(x - hw, y, z - hw, x + hw, y + player.getHeight(), z + hw);
    }
}
