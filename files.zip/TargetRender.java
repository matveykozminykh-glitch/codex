package moscow.rockstar.systems.modules.modules.visuals;

import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import moscow.rockstar.Rockstar;
import moscow.rockstar.systems.event.EventListener;
import moscow.rockstar.systems.event.impl.render.Render3DEvent;
import moscow.rockstar.systems.modules.api.ModuleCategory;
import moscow.rockstar.systems.modules.api.ModuleInfo;
import moscow.rockstar.systems.modules.impl.BaseModule;
import moscow.rockstar.systems.setting.settings.BooleanSetting;
import moscow.rockstar.systems.setting.settings.ColorSetting;
import moscow.rockstar.systems.setting.settings.ModeSetting;
import moscow.rockstar.systems.setting.settings.SliderSetting;
import moscow.rockstar.utility.animation.base.Animation;
import moscow.rockstar.utility.animation.base.Easing;
import moscow.rockstar.utility.colors.ColorRGBA;
import moscow.rockstar.utility.colors.Colors;
import moscow.rockstar.utility.math.MathUtility;
import moscow.rockstar.utility.render.DrawUtility;
import moscow.rockstar.utility.render.RenderUtility;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

@ModuleInfo(name = "Target Render", category = ModuleCategory.VISUALS, desc = "Расширенный Target ESP: Ghosts, Sphere, Spiral")
public class TargetRender extends BaseModule {

    private final ModeSetting mode = new ModeSetting(this, "modules.settings.target_render.mode");
    private final ModeSetting.Value ghosts = new ModeSetting.Value(this.mode, "Ghosts").select();
    private final ModeSetting.Value sphere = new ModeSetting.Value(this.mode, "Sphere");
    private final ModeSetting.Value spiral = new ModeSetting.Value(this.mode, "Spiral");
    private final ModeSetting.Value aura = new ModeSetting.Value(this.mode, "Aura");

    private final ColorSetting color = new ColorSetting(this, "modules.settings.target_render.color").color(Colors.ACCENT);
    private final SliderSetting size = new SliderSetting(this, "modules.settings.target_render.size")
            .min(0.5F).max(3.0F).step(0.1F).currentValue(1.2F);
    private final SliderSetting speed = new SliderSetting(this, "modules.settings.target_render.speed")
            .min(0.1F).max(5.0F).step(0.1F).currentValue(1.5F);
    private final SliderSetting particleCount = new SliderSetting(this, "modules.settings.target_render.count")
            .min(10.0F).max(100.0F).step(5.0F).currentValue(40.0F);
    private final BooleanSetting glowEffect = new BooleanSetting(this, "modules.settings.target_render.glow").enable();

    private final Animation animation = new Animation(350L, 0.0F, Easing.FIGMA_EASE_IN_OUT);
    private final Animation moving = new Animation(70L, 0.0F, Easing.LINEAR);
    private LivingEntity prevTarget = null;

    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (!moscow.rockstar.utility.game.EntityUtility.isInGame()) return;

        LivingEntity target = Rockstar.getInstance().getTargetManager().getCurrentTarget() instanceof LivingEntity t ? t : null;
        animation.update(target != null);
        moving.update(moving.getValue() + 8.0F + 40.0F * speed.getCurrentValue());

        if (target != null) prevTarget = target;
        if (prevTarget == null || animation.getValue() == 0.0F) return;

        MatrixStack ms = event.getMatrices();
        Camera camera = event.getCamera();
        ms.push();

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);

        if (ghosts.isSelected()) drawGhosts(ms, camera);
        else if (sphere.isSelected()) drawSphere(ms, camera);
        else if (spiral.isSelected()) drawSpiral(ms, camera);
        else if (aura.isSelected()) drawAura(ms, camera);

        RenderSystem.depthMask(true);
        RenderSystem.setShaderTexture(0, 0);
        RenderSystem.disableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        ms.pop();
    };

    // ── GHOSTS MODE ─────────────────────────────────────────────────────────────
    private void drawGhosts(MatrixStack ms, Camera camera) {
        Identifier tex = Rockstar.id("textures/bloom.png");
        RenderSystem.setShaderTexture(0, tex);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        ColorRGBA col = color.getColor();
        float w = prevTarget.getWidth() * size.getCurrentValue() * 1.5F;
        RenderUtility.prepareMatrices(ms, getRenderPos(prevTarget));

        int step = 2;
        int wormTick = 0, wormCD = 0;

        for (int i = 0; i < 360; i += step) {
            if (wormCD > 0) { wormCD -= step; continue; }
            wormTick += step;
            if (wormTick > 60) { wormCD = 80; wormTick = 0; continue; }

            float val = Math.max(0.45F, 1.2F - 0.5F * animation.getValue());
            float sin = (float)(MathUtility.sin((float)Math.toRadians(i + moving.getValue())) * w * val);
            float cos = (float)(MathUtility.cos((float)Math.toRadians(i + moving.getValue())) * w * val);

            float yPos = prevTarget.getHeight() / 1.4F
                    + prevTarget.getHeight() / 3.0F * MathUtility.sin(Math.toRadians(i / 2.0F + moving.getValue() / 5.0F));
            float particleSize = 0.12F + 0.004F * wormTick;
            float bigSize = 0.6F + 0.004F * wormTick;

            ms.push();
            ms.translate(sin, yPos, cos);
            ms.multiply(camera.getRotation());

            // Glow halo
            DrawUtility.drawImage(ms, builder,
                    -bigSize / 2.0, -bigSize / 2.0, -bigSize / 2.0, bigSize, bigSize,
                    col.withAlpha(col.getAlpha() * animation.getValue() * 0.04F));
            // Core dot
            DrawUtility.drawImage(ms, builder,
                    -particleSize / 2.0, -particleSize / 2.0, -particleSize / 2.0, particleSize, particleSize,
                    col.withAlpha(col.getAlpha() * animation.getValue() * 0.9F));
            ms.pop();
        }
        BufferRenderer.drawWithGlobalProgram(builder.end());
    }

    // ── SPHERE MODE ─────────────────────────────────────────────────────────────
    private void drawSphere(MatrixStack ms, Camera camera) {
        Identifier tex = Rockstar.id("textures/bloom.png");
        RenderSystem.setShaderTexture(0, tex);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        ColorRGBA col = color.getColor();
        Vec3d center = getRenderPos(prevTarget).add(0, prevTarget.getHeight() / 2.0, 0);
        float radius = prevTarget.getWidth() * size.getCurrentValue() * 1.2F;
        int cnt = (int) particleCount.getCurrentValue();

        RenderUtility.prepareMatrices(ms, center);

        // Golden-angle sphere distribution
        float goldenAngle = (float)(Math.PI * (3.0 - Math.sqrt(5.0)));
        float timeOffset = moving.getValue() * 0.02F;

        for (int i = 0; i < cnt; i++) {
            float progress = (float) i / cnt;
            float y = 1.0F - progress * 2.0F;
            float r = (float) Math.sqrt(1.0 - y * y);
            float theta = goldenAngle * i + timeOffset;

            float x = (float)(Math.cos(theta) * r * radius);
            float pY = y * radius;
            float z = (float)(Math.sin(theta) * r * radius);

            float pulse = glowEffect.isEnabled()
                    ? 0.5F + 0.5F * MathHelper.sin(moving.getValue() * 0.05F + i * 0.3F)
                    : 0.8F;
            float pSize = 0.08F + 0.04F * pulse;

            ms.push();
            ms.translate(x, pY, z);
            ms.multiply(camera.getRotation());
            DrawUtility.drawImage(ms, builder, -pSize / 2.0, -pSize / 2.0, 0.0, pSize, pSize,
                    col.withAlpha(col.getAlpha() * animation.getValue() * pulse * 0.85F));
            ms.pop();
        }
        BufferRenderer.drawWithGlobalProgram(builder.end());
    }

    // ── SPIRAL MODE ─────────────────────────────────────────────────────────────
    private void drawSpiral(MatrixStack ms, Camera camera) {
        Identifier tex = Rockstar.id("textures/bloom.png");
        RenderSystem.setShaderTexture(0, tex);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        ColorRGBA col = color.getColor();
        Vec3d base = getRenderPos(prevTarget);
        float radius = prevTarget.getWidth() * size.getCurrentValue() * 1.3F;
        int cnt = (int) particleCount.getCurrentValue();
        int spiralCount = 3; // triple helix

        RenderUtility.prepareMatrices(ms, base);

        for (int s = 0; s < spiralCount; s++) {
            float spiralOffset = (float)(s * Math.PI * 2.0 / spiralCount);
            for (int i = 0; i < cnt; i++) {
                float progress = (float) i / cnt;
                float angle = progress * (float)(Math.PI * 4.0) + moving.getValue() * 0.04F + spiralOffset;
                float spiralRadius = radius * (0.6F + 0.4F * MathHelper.sin(progress * (float)Math.PI));
                float x = MathHelper.cos(angle) * spiralRadius;
                float y = prevTarget.getHeight() * progress;
                float z = MathHelper.sin(angle) * spiralRadius;

                float alpha = MathHelper.sin(progress * (float)Math.PI);
                float pSize = 0.07F + 0.05F * alpha;

                ms.push();
                ms.translate(x, y, z);
                ms.multiply(camera.getRotation());
                DrawUtility.drawImage(ms, builder, -pSize / 2.0, -pSize / 2.0, 0.0, pSize, pSize,
                        col.withAlpha(col.getAlpha() * animation.getValue() * alpha * 0.9F));
                ms.pop();
            }
        }
        BufferRenderer.drawWithGlobalProgram(builder.end());
    }

    // ── AURA MODE ───────────────────────────────────────────────────────────────
    private void drawAura(MatrixStack ms, Camera camera) {
        Identifier tex = Rockstar.id("textures/bloom.png");
        RenderSystem.setShaderTexture(0, tex);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        ColorRGBA col = color.getColor();
        Vec3d base = getRenderPos(prevTarget).add(0, prevTarget.getHeight() / 2.0, 0);
        float radius = prevTarget.getWidth() * size.getCurrentValue() * 1.5F;

        RenderUtility.prepareMatrices(ms, base);

        // Rotating ring of bloom dots at entity center height + above/below
        for (int ring = 0; ring < 3; ring++) {
            float ringRadius = radius * (0.7F + ring * 0.3F);
            float ringY = prevTarget.getHeight() * (ring - 1) * 0.3F;
            float ringSpeed = (ring % 2 == 0 ? 1.0F : -1.3F) * speed.getCurrentValue();
            int ringCnt = 12 + ring * 6;

            for (int i = 0; i < ringCnt; i++) {
                float angle = (float)(Math.PI * 2.0 * i / ringCnt) + moving.getValue() * 0.04F * ringSpeed;
                float x = MathHelper.cos(angle) * ringRadius;
                float z = MathHelper.sin(angle) * ringRadius;

                float pulse = glowEffect.isEnabled()
                        ? 0.4F + 0.6F * MathHelper.sin(moving.getValue() * 0.06F + i * 0.5F + ring)
                        : 0.7F;
                float pSize = (0.12F + 0.08F * pulse) * animation.getValue();

                ms.push();
                ms.translate(x, ringY, z);
                ms.multiply(camera.getRotation());
                // Large glow
                DrawUtility.drawImage(ms, builder, -pSize, -pSize, 0.0, pSize * 2.0F, pSize * 2.0F,
                        col.withAlpha(col.getAlpha() * animation.getValue() * pulse * 0.15F));
                // Core
                DrawUtility.drawImage(ms, builder, -pSize / 2.0, -pSize / 2.0, 0.0, pSize, pSize,
                        col.withAlpha(col.getAlpha() * animation.getValue() * pulse * 0.8F));
                ms.pop();
            }
        }

        // Center bloom pulse
        float centerSize = 0.8F * size.getCurrentValue() * (0.8F + 0.2F * MathHelper.sin(moving.getValue() * 0.04F));
        ms.push();
        ms.multiply(camera.getRotation());
        DrawUtility.drawImage(ms, builder, -centerSize / 2.0, -centerSize / 2.0, 0.0, centerSize, centerSize,
                col.withAlpha(col.getAlpha() * animation.getValue() * 0.25F));
        ms.pop();

        BufferRenderer.drawWithGlobalProgram(builder.end());
    }

    private Vec3d getRenderPos(LivingEntity entity) {
        float td = MinecraftClient.getInstance().getRenderTickCounter().getTickDelta(false);
        return new Vec3d(
                MathHelper.lerp(td, entity.prevX, entity.getX()),
                MathHelper.lerp(td, entity.prevY, entity.getY()),
                MathHelper.lerp(td, entity.prevZ, entity.getZ())
        );
    }

    @Override
    public void onDisable() {
        prevTarget = null;
        animation.forceValue(0.0F);
        super.onDisable();
    }
}
