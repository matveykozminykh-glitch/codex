package moscow.rockstar.systems.modules.modules.visuals;

import moscow.rockstar.Rockstar;
import moscow.rockstar.systems.modules.api.ModuleCategory;
import moscow.rockstar.systems.modules.api.ModuleInfo;
import moscow.rockstar.systems.modules.impl.BaseModule;
import moscow.rockstar.systems.setting.settings.BooleanSetting;
import moscow.rockstar.systems.setting.settings.SliderSetting;

/**
 * ItemPhysics — физика выпавших предметов.
 * Требует Mixin: ItemEntityRendererMixin (смотри ниже)
 */
@ModuleInfo(name = "Item Physics", category = ModuleCategory.VISUALS, desc = "Физика выпавших предметов — они падают плашмя")
public class ItemPhysics extends BaseModule {

    private final BooleanSetting flatItems = new BooleanSetting(this, "modules.settings.item_physics.flat").enable();
    private final BooleanSetting spinOnGround = new BooleanSetting(this, "modules.settings.item_physics.spin_on_ground");
    private final SliderSetting spinSpeed = new SliderSetting(this, "modules.settings.item_physics.spin_speed")
            .min(0.5F).max(5.0F).step(0.1F).currentValue(2.0F);
    private final BooleanSetting scaleByCount = new BooleanSetting(this, "modules.settings.item_physics.scale_by_count");

    public static boolean isEnabled() {
        return Rockstar.getInstance().getModuleManager().getModule(ItemPhysics.class).isEnabled();
    }

    public static boolean isFlatItems() {
        ItemPhysics m = Rockstar.getInstance().getModuleManager().getModule(ItemPhysics.class);
        return m.isEnabled() && m.flatItems.isEnabled();
    }

    public static boolean isSpinOnGround() {
        ItemPhysics m = Rockstar.getInstance().getModuleManager().getModule(ItemPhysics.class);
        return m.isEnabled() && m.spinOnGround.isEnabled();
    }

    public static float getSpinSpeed() {
        return Rockstar.getInstance().getModuleManager().getModule(ItemPhysics.class).spinSpeed.getCurrentValue();
    }

    public static boolean isScaleByCount() {
        ItemPhysics m = Rockstar.getInstance().getModuleManager().getModule(ItemPhysics.class);
        return m.isEnabled() && m.scaleByCount.isEnabled();
    }
}
