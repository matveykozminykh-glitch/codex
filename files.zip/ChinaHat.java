package moscow.rockstar.systems.modules.modules.visuals;

import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import moscow.rockstar.Rockstar;
import moscow.rockstar.systems.event.EventListener;
import moscow.rockstar.systems.event.impl.render.Render3DEvent;
import moscow.rockstar.systems.modules.api.ModuleCategory;
import moscow.rockstar.systems.modules.api.ModuleInfo;
import moscow.rockstar.systems.modules.impl.BaseModule;
import moscow.rockstar.systems.setting.settings.BooleanSetting;
import moscow.rockstar.systems.setting.settings.ColorSetting;
import moscow.rockstar.systems.setting.settings.ModeSetting;
import moscow.rockstar.systems.setting.settings.SliderSetting;
import moscow.rockstar.utility.colors.ColorRGBA;
import moscow.rockstar.utility.colors.Colors;
import moscow.rockstar.utility.render.RenderUtility;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

@ModuleInfo(name = "China Hat", category = ModuleCategory.VISUALS, desc = "3D шляпа над головами игроков")
public class ChinaHat extends BaseModule {

    private final SliderSetting hatRadius = new SliderSetting(this, "modules.settings.china_hat.radius")
            .min(0.1F).max(1.5F).step(0.05F).currentValue(0.5F);
    private final SliderSetting hatHeight = new SliderSetting(this, "modules.settings.china_hat.height")
            .min(0.05F).max(1.0F).step(0.02F).currentValue(0.3F);
    private final SliderSetting yOffset = new SliderSetting(this, "modules.settings.china_hat.y_offset")
            .min(0.0F).max(0.5F).step(0.01F).currentValue(0.05F);
    private final SliderSetting rotateSpeed = new SliderSetting(this, "modules.settings.china_hat.rotate_speed")
            .min(0.0F).max(5.0F).step(0.1F).currentValue(1.0F);
    private final ColorSetting hatColor = new ColorSetting(this, "modules.settings.china_hat.color").color(Colors.ACCENT);
    private final BooleanSetting outline = new BooleanSetting(this, "modules.settings.china_hat.outline").enable();
    private final BooleanSetting onlyFriends = new BooleanSetting(this, "modules.settings.china_hat.only_friends");
    private final ModeSetting hatStyle = new ModeSetting(this, "modules.settings.china_hat.style");
    private final ModeSetting.Value conical = new ModeSetting.Value(this.hatStyle, "Conical").select();
    private final ModeSetting.Value flat = new ModeSetting.Value(this.hatStyle, "Flat");
    private final ModeSetting.Value wizard = new ModeSetting.Value(this.hatStyle, "Wizard");

    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (mc.world == null || mc.player == null) return;

        Camera camera = event.getCamera();
        MatrixStack matrices = event.getMatrices();
        float tickDelta = event.getTickDelta();
        long time = System.currentTimeMillis();

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player) continue;
            if (!player.isAlive()) continue;
            if (onlyFriends.isEnabled() && !Rockstar.getInstance().getFriendManager().isFriend(player.getName().getString())) continue;

            Vec3d pos = VisualRenderHelper.interpolated(player, tickDelta);
            Vec3d hatPos = pos.add(0, player.getHeight() + yOffset.getCurrentValue(), 0);

            float rotation = (time * 0.001F * rotateSpeed.getCurrentValue() * 60.0F) % 360.0F;
            ColorRGBA color = hatColor.getColor();

            matrices.push();
            RenderUtility.prepareMatrices(matrices, hatPos);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(rotation));

            drawHat(matrices, color);
            matrices.pop();
        }

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    };

    private void drawHat(MatrixStack matrices, ColorRGBA color) {
        float r = hatRadius.getCurrentValue();
        float h = hatHeight.getCurrentValue();
        int segments = 24;

        // Draw filled cone/hat using triangles
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        ColorRGBA tipColor = color.withAlpha(color.getAlpha() * 0.9F);
        ColorRGBA baseColor = color.withAlpha(color.getAlpha() * 0.5F);

        float tipY = h;
        if (wizard.isSelected()) tipY = h * 1.8F;

        for (int i = 0; i < segments; i++) {
            float angle1 = (float)(Math.PI * 2.0 * i / segments);
            float angle2 = (float)(Math.PI * 2.0 * (i + 1) / segments);

            float x1 = MathHelper.cos(angle1) * r;
            float z1 = MathHelper.sin(angle1) * r;
            float x2 = MathHelper.cos(angle2) * r;
            float z2 = MathHelper.sin(angle2) * r;

            if (wizard.isSelected()) {
                // Middle ring for wizard hat
                float mr = r * 0.5F;
                float mh = h * 0.6F;
                float mx1 = MathHelper.cos(angle1) * mr;
                float mz1 = MathHelper.sin(angle1) * mr;
                float mx2 = MathHelper.cos(angle2) * mr;
                float mz2 = MathHelper.sin(angle2) * mr;
                // Base to middle
                builder.vertex(matrix, x1, 0, z1).color(baseColor.getRGB());
                builder.vertex(matrix, x2, 0, z2).color(baseColor.getRGB());
                builder.vertex(matrix, mx2, mh, mz2).color(tipColor.getRGB());
                builder.vertex(matrix, x1, 0, z1).color(baseColor.getRGB());
                builder.vertex(matrix, mx2, mh, mz2).color(tipColor.getRGB());
                builder.vertex(matrix, mx1, mh, mz1).color(tipColor.getRGB());
                // Middle to tip
                builder.vertex(matrix, mx1, mh, mz1).color(tipColor.getRGB());
                builder.vertex(matrix, mx2, mh, mz2).color(tipColor.getRGB());
                builder.vertex(matrix, 0, tipY, 0).color(tipColor.withAlpha(tipColor.getAlpha() * 0.8F).getRGB());
            } else {
                // Simple cone
                builder.vertex(matrix, x1, flat.isSelected() ? h * 0.1F : 0, z1).color(baseColor.getRGB());
                builder.vertex(matrix, x2, flat.isSelected() ? h * 0.1F : 0, z2).color(baseColor.getRGB());
                builder.vertex(matrix, 0, tipY, 0).color(tipColor.getRGB());
            }
        }
        // Bottom cap
        for (int i = 0; i < segments; i++) {
            float angle1 = (float)(Math.PI * 2.0 * i / segments);
            float angle2 = (float)(Math.PI * 2.0 * (i + 1) / segments);
            builder.vertex(matrix, 0, 0, 0).color(baseColor.getRGB());
            builder.vertex(matrix, MathHelper.cos(angle1) * r, 0, MathHelper.sin(angle1) * r).color(baseColor.getRGB());
            builder.vertex(matrix, MathHelper.cos(angle2) * r, 0, MathHelper.sin(angle2) * r).color(baseColor.getRGB());
        }
        RenderUtility.buildBuffer(builder);

        // Outline rim
        if (outline.isEnabled()) {
            RenderSystem.lineWidth(1.5F);
            BufferBuilder lineBuilder = RenderSystem.renderThreadTesselator().begin(DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
            ColorRGBA outlineColor = color;
            for (int i = 0; i < segments; i++) {
                float a1 = (float)(Math.PI * 2.0 * i / segments);
                float a2 = (float)(Math.PI * 2.0 * (i + 1) / segments);
                lineBuilder.vertex(matrix, MathHelper.cos(a1) * r, 0, MathHelper.sin(a1) * r).color(outlineColor.getRGB());
                lineBuilder.vertex(matrix, MathHelper.cos(a2) * r, 0, MathHelper.sin(a2) * r).color(outlineColor.getRGB());
                // Side lines to tip
                if (i % 4 == 0) {
                    lineBuilder.vertex(matrix, MathHelper.cos(a1) * r, 0, MathHelper.sin(a1) * r).color(outlineColor.getRGB());
                    lineBuilder.vertex(matrix, 0, h, 0).color(outlineColor.withAlpha(outlineColor.getAlpha() * 0.5F).getRGB());
                }
            }
            RenderUtility.buildBuffer(lineBuilder);
            RenderSystem.lineWidth(1.0F);
        }
    }
}
