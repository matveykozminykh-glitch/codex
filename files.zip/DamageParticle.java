package moscow.rockstar.systems.modules.modules.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import moscow.rockstar.Rockstar;
import moscow.rockstar.systems.event.EventListener;
import moscow.rockstar.systems.event.impl.game.GameTickEvent;
import moscow.rockstar.systems.event.impl.game.PostAttackEvent;
import moscow.rockstar.systems.event.impl.render.Render3DEvent;
import moscow.rockstar.systems.modules.api.ModuleCategory;
import moscow.rockstar.systems.modules.api.ModuleInfo;
import moscow.rockstar.systems.modules.impl.BaseModule;
import moscow.rockstar.systems.setting.settings.BooleanSetting;
import moscow.rockstar.systems.setting.settings.ColorSetting;
import moscow.rockstar.systems.setting.settings.ModeSetting;
import moscow.rockstar.systems.setting.settings.SliderSetting;
import moscow.rockstar.utility.colors.ColorRGBA;
import moscow.rockstar.utility.colors.Colors;
import moscow.rockstar.utility.game.CombatUtility;
import moscow.rockstar.utility.game.EntityUtility;
import moscow.rockstar.utility.math.MathUtility;
import moscow.rockstar.framework.msdf.Fonts;
import moscow.rockstar.framework.msdf.MsdfRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@ModuleInfo(name = "Damage Particle", category = ModuleCategory.VISUALS, desc = "Текстовые цифры урона как 3D частицы")
public class DamageParticle extends BaseModule {

    private final Map<Integer, PendingDamage> pending = new HashMap<>();
    private final Map<Integer, Integer> hurtTracker = new HashMap<>();
    private final List<DmgText> texts = new ArrayList<>();

    private final SliderSetting textScale = new SliderSetting(this, "modules.settings.damage_particle.scale")
            .min(0.3F).max(3.0F).step(0.1F).currentValue(1.0F);
    private final SliderSetting lifetime = new SliderSetting(this, "modules.settings.damage_particle.lifetime")
            .min(0.5F).max(5.0F).step(0.1F).currentValue(2.5F);
    private final SliderSetting riseSpeed = new SliderSetting(this, "modules.settings.damage_particle.rise_speed")
            .min(0.1F).max(3.0F).step(0.1F).currentValue(0.8F);

    private final ModeSetting colorMode = new ModeSetting(this, "modules.settings.damage_particle.color_mode");
    private final ModeSetting.Value clientColor = new ModeSetting.Value(this.colorMode, "Client").select();
    private final ModeSetting.Value healthColor = new ModeSetting.Value(this.colorMode, "Health");
    private final ModeSetting.Value customColorMode = new ModeSetting.Value(this.colorMode, "Custom");
    private final ColorSetting customColor = new ColorSetting(this, "modules.settings.damage_particle.custom_color")
            .color(Colors.RED);

    private final BooleanSetting showCrit = new BooleanSetting(this, "modules.settings.damage_particle.show_crit").enable();
    private final BooleanSetting onlyCrit = new BooleanSetting(this, "modules.settings.damage_particle.only_crit");
    private final BooleanSetting randomOffset = new BooleanSetting(this, "modules.settings.damage_particle.random_offset");

    private final EventListener<PostAttackEvent> onAttack = event -> {
        if (!EntityUtility.isInGame()) return;
        if (!(event.getEntity() instanceof LivingEntity living) || !living.isAlive()) return;
        boolean crit = CombatUtility.canPerformCriticalHit(living, true);
        if (onlyCrit.isEnabled() && !crit) return;
        pending.put(living.getId(), new PendingDamage(living, getHealth(living), crit));
    };

    private final EventListener<GameTickEvent> onTick = event -> {
        if (!EntityUtility.isInGame()) {
            hurtTracker.clear();
            return;
        }
        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof LivingEntity living) || !living.isAlive()) continue;
            int currentHurt = living.hurtTime;
            int prevHurt = hurtTracker.getOrDefault(living.getId(), 0);
            if (currentHurt > prevHurt) {
                boolean crit = CombatUtility.canPerformCriticalHit(living, true);
                if (!onlyCrit.isEnabled() || crit) {
                    pending.putIfAbsent(living.getId(), new PendingDamage(living, getHealth(living), crit));
                }
            }
            hurtTracker.put(living.getId(), currentHurt);
        }

        Iterator<PendingDamage> it = pending.values().iterator();
        while (it.hasNext()) {
            PendingDamage p = it.next();
            if (!p.entity.isAlive()) { it.remove(); continue; }
            float dmg = p.prevHealth - getHealth(p.entity);
            if (dmg > 0.1F) {
                Vec3d spawnPos = VisualRenderHelper.interpolated(p.entity, mc.getRenderTickCounter().getTickDelta(false))
                        .add(
                            randomOffset.isEnabled() ? MathUtility.random(-p.entity.getWidth() * 0.4, p.entity.getWidth() * 0.4) : 0,
                            p.entity.getHeight() * (randomOffset.isEnabled() ? MathUtility.random(0.5, 0.9) : 0.7),
                            randomOffset.isEnabled() ? MathUtility.random(-p.entity.getWidth() * 0.4, p.entity.getWidth() * 0.4) : 0
                        );
                Vec3d vel = new Vec3d(MathUtility.random(-0.01, 0.01), riseSpeed.getCurrentValue() * 0.01, MathUtility.random(-0.01, 0.01));
                long life = (long)(lifetime.getCurrentValue() * 1000L);
                texts.add(new DmgText(spawnPos, vel, dmg, colorFor(p.entity), p.crit, life));
                it.remove();
            } else if (System.currentTimeMillis() - p.time > 450L) {
                it.remove();
            }
        }
    };

    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (texts.isEmpty()) return;
        Camera camera = event.getCamera();
        MatrixStack matrices = event.getMatrices();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();

        Iterator<DmgText> it = texts.iterator();
        while (it.hasNext()) {
            DmgText t = it.next();
            if (t.isDead()) { it.remove(); continue; }
            t.update();

            float progress = t.getProgress();
            float alpha = progress < 0.15F ? (progress / 0.15F) : (1.0F - (progress - 0.15F) / 0.85F);
            float scale = textScale.getCurrentValue() * 0.02F * (1.0F + (t.crit ? 0.3F : 0.0F) * (1.0F - progress));
            ColorRGBA color = t.color.withAlpha(t.color.getAlpha() * Math.max(0, alpha));

            String label = (t.crit && showCrit.isEnabled() ? "✦ " : "") + String.format("%.1f", t.damage);

            matrices.push();
            matrices.translate(
                t.position.x - camera.getPos().x,
                t.position.y - camera.getPos().y,
                t.position.z - camera.getPos().z
            );
            matrices.multiply(camera.getRotation());
            matrices.scale(-scale, -scale, scale);
            float w = Fonts.SEMIBOLD.getWidth(label, 9.0F);
            MsdfRenderer.renderText(Fonts.SEMIBOLD, label, 9.0F, color.getRGB(), matrices.peek().getPositionMatrix(), -w / 2.0F, 0.0F, 0.0F);
            matrices.pop();
        }

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    };

    private ColorRGBA colorFor(LivingEntity entity) {
        if (healthColor.isSelected()) {
            float pct = getHealth(entity) / Math.max(1F, entity.getMaxHealth());
            return pct > 0.65F ? Colors.GREEN : (pct > 0.35F ? new ColorRGBA(255, 215, 0, 255) : Colors.RED);
        }
        if (customColorMode.isSelected()) return customColor.getColor();
        return Colors.ACCENT;
    }

    private float getHealth(LivingEntity e) {
        return e.getHealth() + e.getAbsorptionAmount();
    }

    @Override
    public void onDisable() {
        pending.clear();
        hurtTracker.clear();
        texts.clear();
        super.onDisable();
    }

    private static final class PendingDamage {
        final LivingEntity entity;
        final float prevHealth;
        final boolean crit;
        final long time = System.currentTimeMillis();
        PendingDamage(LivingEntity e, float h, boolean c) { entity = e; prevHealth = h; crit = c; }
    }

    private static final class DmgText {
        Vec3d position;
        Vec3d velocity;
        final float damage;
        final ColorRGBA color;
        final boolean crit;
        final long spawnTime, lifeTime;
        long lastUpdate;

        DmgText(Vec3d pos, Vec3d vel, float dmg, ColorRGBA color, boolean crit, long life) {
            position = pos; velocity = vel; damage = dmg; this.color = color; this.crit = crit;
            lifeTime = life; spawnTime = System.currentTimeMillis(); lastUpdate = spawnTime;
        }

        void update() {
            long now = System.currentTimeMillis();
            float d = Math.max(0.001F, (now - lastUpdate) / 50.0F);
            lastUpdate = now;
            position = position.add(velocity.x * d, velocity.y * d, velocity.z * d);
            velocity = velocity.multiply(0.985);
        }

        float getProgress() { return MathHelper.clamp((float)(System.currentTimeMillis() - spawnTime) / (float)lifeTime, 0, 1); }
        boolean isDead() { return System.currentTimeMillis() - spawnTime >= lifeTime; }
    }
}
