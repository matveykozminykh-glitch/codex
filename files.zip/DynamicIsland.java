package moscow.rockstar.systems.modules.modules.visuals;

import moscow.rockstar.framework.objects.BorderRadius;
import moscow.rockstar.systems.event.EventListener;
import moscow.rockstar.systems.event.impl.render.HudRenderEvent;
import moscow.rockstar.systems.modules.api.ModuleCategory;
import moscow.rockstar.systems.modules.api.ModuleInfo;
import moscow.rockstar.systems.modules.impl.BaseModule;
import moscow.rockstar.systems.setting.settings.BooleanSetting;
import moscow.rockstar.systems.setting.settings.ModeSetting;
import moscow.rockstar.systems.setting.settings.SliderSetting;
import moscow.rockstar.utility.animation.base.Animation;
import moscow.rockstar.utility.animation.base.Easing;
import moscow.rockstar.utility.colors.ColorRGBA;
import moscow.rockstar.utility.colors.Colors;
import moscow.rockstar.utility.game.EntityUtility;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;

@ModuleInfo(name = "Dynamic Island", category = ModuleCategory.VISUALS, desc = "HUD элемент в стиле Dynamic Island")
public class DynamicIsland extends BaseModule {

    // State tracking
    private IslandState currentState = IslandState.IDLE;
    private IslandState prevState = IslandState.IDLE;
    private String islandText = "";
    private String islandSubText = "";
    private long stateTimer = 0;

    // Animations
    private final Animation widthAnim = new Animation(350L, Easing.FIGMA_EASE_IN_OUT);
    private final Animation heightAnim = new Animation(300L, Easing.FIGMA_EASE_IN_OUT);
    private final Animation alphaAnim = new Animation(250L, Easing.CUBIC_IN_OUT);

    // Settings
    private final SliderSetting posX = new SliderSetting(this, "modules.settings.dynamic_island.x")
            .min(0.0F).max(100.0F).step(0.1F).currentValue(50.0F);
    private final SliderSetting posY = new SliderSetting(this, "modules.settings.dynamic_island.y")
            .min(0.0F).max(20.0F).step(0.5F).currentValue(3.0F);
    private final SliderSetting displayTime = new SliderSetting(this, "modules.settings.dynamic_island.time")
            .min(1.0F).max(10.0F).step(0.5F).currentValue(3.0F);

    private final BooleanSetting showHealth = new BooleanSetting(this, "modules.settings.dynamic_island.health").enable();
    private final BooleanSetting showTarget = new BooleanSetting(this, "modules.settings.dynamic_island.target").enable();
    private final BooleanSetting showEffects = new BooleanSetting(this, "modules.settings.dynamic_island.effects").enable();
    private final BooleanSetting showTotem = new BooleanSetting(this, "modules.settings.dynamic_island.totem").enable();

    private final ModeSetting islandTheme = new ModeSetting(this, "modules.settings.dynamic_island.theme");
    private final ModeSetting.Value dark = new ModeSetting.Value(this.islandTheme, "Dark").select();
    private final ModeSetting.Value accent = new ModeSetting.Value(this.islandTheme, "Accent");
    private final ModeSetting.Value glass = new ModeSetting.Value(this.islandTheme, "Glass");

    // State tracking for events
    private float lastHealth = -1;
    private boolean hadTarget = false;

    private enum IslandState { IDLE, HEALTH_CHANGE, TARGET_LOCK, EFFECT_GAIN, TOTEM_LOW }

    private final EventListener<HudRenderEvent> onHud = event -> {
        if (!EntityUtility.isInGame()) return;

        MatrixStack matrices = event.getContext().getMatrices();
        float w = event.getContext().getScaledWindowWidth();
        float tickDelta = event.getTickDelta();

        // Update state
        updateState();

        boolean expanded = currentState != IslandState.IDLE;
        float targetW = expanded ? getExpandedWidth() : 46.0F;
        float targetH = expanded ? getExpandedHeight() : 14.0F;

        widthAnim.update(expanded ? targetW / 200.0F : 0.0F);
        heightAnim.update(expanded ? 1.0F : 0.0F);
        alphaAnim.update(1.0F);

        float animW = expanded ? MathHelper.lerp(widthAnim.getValue(), 46.0F, targetW) : 46.0F;
        float animH = expanded ? MathHelper.lerp(heightAnim.getValue(), 14.0F, targetH) : 14.0F;

        // Position
        float x = w * (posX.getCurrentValue() / 100.0F) - animW / 2.0F;
        float y = posY.getCurrentValue();
        float radius = animH / 2.0F;

        // Background
        ColorRGBA bgColor = getBackgroundColor();
        ColorRGBA borderColor = getBorderColor();

        event.getContext().drawRoundedRect(x, y, animW, animH, BorderRadius.all(radius), bgColor);
        event.getContext().drawRoundedBorder(x, y, animW, animH, BorderRadius.all(radius), 0.8F, borderColor);

        // Content - only when expanded
        if (expanded && heightAnim.getValue() > 0.5F) {
            float contentAlpha = MathHelper.clamp((heightAnim.getValue() - 0.5F) * 2.0F, 0, 1);
            renderContent(event, x, y, animW, animH, contentAlpha);
        }

        // Idle: show small dots
        if (!expanded) {
            renderIdleDots(event, x, y, animW, animH);
        }
    };

    private void updateState() {
        if (mc.player == null) return;
        long now = System.currentTimeMillis();

        // Health change
        if (showHealth.isEnabled()) {
            float hp = mc.player.getHealth();
            if (lastHealth >= 0 && Math.abs(hp - lastHealth) > 0.5F) {
                boolean isLoss = hp < lastHealth;
                float diff = lastHealth - hp;
                setIslandState(IslandState.HEALTH_CHANGE,
                        isLoss ? "⚠ -" + String.format("%.1f", diff) : "♥ +" + String.format("%.1f", -diff),
                        "HP: " + String.format("%.1f", hp) + "/" + String.format("%.0f", mc.player.getMaxHealth()));
            }
            lastHealth = hp;
        }

        // Target lock
        if (showTarget.isEnabled()) {
            var target = Rockstar.getInstance().getTargetManager().getCurrentTarget();
            boolean hasTarget = target != null;
            if (hasTarget && !hadTarget) {
                setIslandState(IslandState.TARGET_LOCK, "🎯 Target", target.getName().getString());
            }
            hadTarget = hasTarget;
        }

        // Low health → totem warning
        if (showTotem.isEnabled() && mc.player.getHealth() < 6.0F) {
            boolean hasTotem = mc.player.getMainHandStack().isOf(Items.TOTEM_OF_UNDYING)
                    || mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
            if (!hasTotem) {
                setIslandState(IslandState.TOTEM_LOW, "⚠ LOW HP", "No totem!");
            }
        }

        // Effect gain
        if (showEffects.isEnabled() && currentState == IslandState.IDLE) {
            for (StatusEffectInstance effect : mc.player.getStatusEffects()) {
                if (effect.getDuration() > 10 && effect.getDuration() % 20 == 1) {
                    String name = effect.getEffectType().value().getName().getString();
                    setIslandState(IslandState.EFFECT_GAIN, name, "Lvl " + (effect.getAmplifier() + 1));
                    break;
                }
            }
        }

        // Auto-reset state after display time
        if (currentState != IslandState.IDLE && now - stateTimer > (long)(displayTime.getCurrentValue() * 1000L)) {
            currentState = IslandState.IDLE;
        }
    }

    private void setIslandState(IslandState state, String text, String subText) {
        if (currentState == state && islandText.equals(text)) return;
        currentState = state;
        islandText = text;
        islandSubText = subText;
        stateTimer = System.currentTimeMillis();
    }

    private void renderContent(HudRenderEvent event, float x, float y, float w, float h, float alpha) {
        MatrixStack matrices = event.getContext().getMatrices();
        ColorRGBA textColor = new ColorRGBA(255, 255, 255, (int)(255 * alpha));
        ColorRGBA subColor = new ColorRGBA(180, 180, 180, (int)(200 * alpha));

        float cx = x + w / 2.0F;
        float cy = y + h / 2.0F;

        // Use client's font rendering
        float textW = mc.textRenderer.getWidth(islandText);
        float subW = mc.textRenderer.getWidth(islandSubText);

        event.getContext().drawText(
                mc.textRenderer, islandText,
                (int)(cx - textW / 2.0F), (int)(cy - 8),
                textColor.getRGB(), false
        );
        if (!islandSubText.isEmpty()) {
            event.getContext().drawText(
                    mc.textRenderer, islandSubText,
                    (int)(cx - subW / 2.0F), (int)(cy + 1),
                    subColor.getRGB(), false
            );
        }
    }

    private void renderIdleDots(HudRenderEvent event, float x, float y, float w, float h) {
        float cx = x + w / 2.0F;
        float cy = y + h / 2.0F;
        float pulse = 0.6F + 0.4F * MathHelper.sin((float)(System.currentTimeMillis() * 0.002));
        ColorRGBA dotColor = accent.isSelected()
                ? Colors.ACCENT.withAlpha(150.0F * pulse)
                : new ColorRGBA(255, 255, 255, (int)(120 * pulse));

        for (int i = -1; i <= 1; i++) {
            event.getContext().drawRect(cx + i * 5 - 1, cy - 1, 2, 2, dotColor);
        }
    }

    private float getExpandedWidth() {
        switch (currentState) {
            case HEALTH_CHANGE: return 100.0F;
            case TARGET_LOCK: return 120.0F;
            case TOTEM_LOW: return 110.0F;
            case EFFECT_GAIN: return 130.0F;
            default: return 80.0F;
        }
    }

    private float getExpandedHeight() {
        return islandSubText.isEmpty() ? 22.0F : 30.0F;
    }

    private ColorRGBA getBackgroundColor() {
        if (accent.isSelected()) return Colors.ACCENT.withAlpha(220.0F);
        if (glass.isSelected()) return new ColorRGBA(20, 20, 20, 170);
        return new ColorRGBA(10, 10, 10, 230);
    }

    private ColorRGBA getBorderColor() {
        if (currentState == IslandState.TOTEM_LOW) return new ColorRGBA(255, 80, 80, 180);
        if (accent.isSelected()) return Colors.ACCENT.withAlpha(100.0F);
        return new ColorRGBA(60, 60, 60, 150);
    }

    @Override
    public void onDisable() {
        currentState = IslandState.IDLE;
        lastHealth = -1;
        hadTarget = false;
        super.onDisable();
    }
}
