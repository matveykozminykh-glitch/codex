package moscow.rockstar.mixin.minecraft.client.render;

import moscow.rockstar.systems.modules.modules.visuals.ItemPhysics;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemEntityRenderer.class)
public class ItemEntityRendererMixin {

    @Inject(
        method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
        at = @At("HEAD"),
        cancellable = true
    )
    private void onRender(ItemEntityRenderState state, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        if (!ItemPhysics.isEnabled()) return;

        // Cancel vanilla render, we'll apply our custom transforms
        // (The vanilla render still runs after HEAD unless we override the whole thing)
        // Instead we modify the matrices before vanilla render executes
    }

    @Inject(
        method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/util/math/MatrixStack;push()V",
            ordinal = 0
        )
    )
    private void applyPhysicsTransform(ItemEntityRenderState state, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        if (!ItemPhysics.isEnabled()) return;

        // Lay item flat (rotate 90 degrees on X axis)
        if (ItemPhysics.isFlatItems()) {
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0F));
        }

        // When on ground, optionally spin slowly
        if (ItemPhysics.isSpinOnGround()) {
            float spin = (float)(System.currentTimeMillis() * 0.001 * ItemPhysics.getSpinSpeed() * 60.0);
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(spin % 360.0F));
        }

        // Scale by stack count
        if (ItemPhysics.isScaleByCount()) {
            int count = state.count;
            float scale = count > 16 ? 1.2F : (count > 4 ? 1.1F : 1.0F);
            matrices.scale(scale, scale, scale);
        }
    }
}
