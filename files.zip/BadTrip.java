package moscow.rockstar.systems.modules.modules.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import moscow.rockstar.Rockstar;
import moscow.rockstar.systems.event.EventListener;
import moscow.rockstar.systems.event.impl.game.PostAttackEvent;
import moscow.rockstar.systems.event.impl.render.HudRenderEvent;
import moscow.rockstar.systems.modules.api.ModuleCategory;
import moscow.rockstar.systems.modules.api.ModuleInfo;
import moscow.rockstar.systems.modules.impl.BaseModule;
import moscow.rockstar.systems.setting.settings.BooleanSetting;
import moscow.rockstar.systems.setting.settings.ModeSetting;
import moscow.rockstar.systems.setting.settings.SliderSetting;
import moscow.rockstar.utility.animation.base.Animation;
import moscow.rockstar.utility.animation.base.Easing;
import moscow.rockstar.utility.colors.ColorRGBA;
import moscow.rockstar.utility.colors.Colors;
import moscow.rockstar.utility.render.DrawUtility;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix4f;

@ModuleInfo(name = "Bad Trip", category = ModuleCategory.VISUALS, desc = "Искажение экрана при атаке на цель")
public class BadTrip extends BaseModule {

    private final Animation hitAnim = new Animation(400L, 0.0F, Easing.FIGMA_EASE_IN_OUT);
    private boolean triggered = false;

    private final ModeSetting style = new ModeSetting(this, "modules.settings.bad_trip.style");
    private final ModeSetting.Value vignette = new ModeSetting.Value(this.style, "Vignette").select();
    private final ModeSetting.Value flash = new ModeSetting.Value(this.style, "Flash");
    private final ModeSetting.Value combined = new ModeSetting.Value(this.style, "Combined");

    private final SliderSetting intensity = new SliderSetting(this, "modules.settings.bad_trip.intensity")
            .min(0.1F).max(1.0F).step(0.05F).currentValue(0.5F);
    private final SliderSetting duration = new SliderSetting(this, "modules.settings.bad_trip.duration")
            .min(100.0F).max(1000.0F).step(50.0F).currentValue(400.0F);

    private final BooleanSetting colorTint = new BooleanSetting(this, "modules.settings.bad_trip.color_tint").enable();
    private final BooleanSetting onlyHurt = new BooleanSetting(this, "modules.settings.bad_trip.only_hurt");

    private final EventListener<PostAttackEvent> onAttack = event -> {
        if (!(event.getEntity() instanceof LivingEntity target)) return;
        if (onlyHurt.isEnabled() && target.hurtTime <= 0) return;
        triggered = true;
        hitAnim.setDuration((long) duration.getCurrentValue());
    };

    private final EventListener<HudRenderEvent> onHud = event -> {
        hitAnim.setEasing(Easing.CUBIC_IN_OUT);
        hitAnim.update(triggered);
        if (triggered && hitAnim.getValue() >= 0.99F) triggered = false;

        float val = hitAnim.getValue();
        if (val <= 0.001F) return;

        float w = event.getContext().getScaledWindowWidth();
        float h = event.getContext().getScaledWindowHeight();
        MatrixStack matrices = event.getContext().getMatrices();
        float strength = val * intensity.getCurrentValue();

        if (vignette.isSelected() || combined.isSelected()) {
            drawVignette(matrices, w, h, strength);
        }
        if (flash.isSelected() || combined.isSelected()) {
            drawFlash(matrices, w, h, strength * 0.4F);
        }
    };

    private void drawVignette(MatrixStack matrices, float w, float h, float strength) {
        ColorRGBA center = new ColorRGBA(0, 0, 0, 0);
        ColorRGBA edge = colorTint.isEnabled()
                ? Colors.ACCENT.withAlpha(255.0F * strength * 0.85F)
                : new ColorRGBA(0, 0, 0, (int)(255 * strength * 0.85F));

        // Radial gradient: draw 4 quads from edges fading to center
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        Matrix4f m = matrices.peek().getPositionMatrix();

        float vSize = Math.min(w, h) * 0.45F;

        // Left gradient
        gradientQuadH(m, builder, 0, 0, vSize, h, edge, center);
        // Right gradient
        gradientQuadH(m, builder, w - vSize, 0, vSize, h, center, edge);
        // Top gradient
        gradientQuadV(m, builder, 0, 0, w, vSize, edge, center);
        // Bottom gradient
        gradientQuadV(m, builder, 0, h - vSize, w, vSize, center, edge);

        moscow.rockstar.utility.render.RenderUtility.buildBuffer(builder);
        RenderSystem.disableBlend();
    }

    private void drawFlash(MatrixStack matrices, float w, float h, float strength) {
        if (strength <= 0.001F) return;
        // Brief white/accent flash
        ColorRGBA flashColor = colorTint.isEnabled()
                ? Colors.ACCENT.withAlpha(255.0F * strength)
                : new ColorRGBA(255, 255, 255, (int)(255 * strength));

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        DrawUtility.drawRect(matrices, 0, 0, w, h, flashColor);
        RenderSystem.disableBlend();
    }

    private void gradientQuadH(Matrix4f m, BufferBuilder b, float x, float y, float w, float h, ColorRGBA left, ColorRGBA right) {
        b.vertex(m, x,     y,     0).color(left.getRGB());
        b.vertex(m, x + w, y,     0).color(right.getRGB());
        b.vertex(m, x + w, y + h, 0).color(right.getRGB());
        b.vertex(m, x,     y + h, 0).color(left.getRGB());
    }

    private void gradientQuadV(Matrix4f m, BufferBuilder b, float x, float y, float w, float h, ColorRGBA top, ColorRGBA bottom) {
        b.vertex(m, x,     y,     0).color(top.getRGB());
        b.vertex(m, x + w, y,     0).color(top.getRGB());
        b.vertex(m, x + w, y + h, 0).color(bottom.getRGB());
        b.vertex(m, x,     y + h, 0).color(bottom.getRGB());
    }

    @Override
    public void onDisable() {
        triggered = false;
        hitAnim.forceValue(0.0F);
        super.onDisable();
    }
}
