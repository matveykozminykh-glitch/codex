package moscow.rockstar.systems.modules.modules.visuals;

import moscow.rockstar.systems.event.EventListener;
import moscow.rockstar.systems.event.impl.network.ReceivePacketEvent;
import moscow.rockstar.systems.modules.api.ModuleCategory;
import moscow.rockstar.systems.modules.api.ModuleInfo;
import moscow.rockstar.systems.modules.impl.BaseModule;
import moscow.rockstar.systems.setting.settings.BooleanSetting;
import moscow.rockstar.systems.setting.settings.ModeSetting;
import moscow.rockstar.systems.setting.settings.SliderSetting;
import moscow.rockstar.utility.game.EntityUtility;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;

@ModuleInfo(name = "World Time", category = ModuleCategory.VISUALS, desc = "Кастомное время суток")
public class WorldTime extends BaseModule {

    private final ModeSetting preset = new ModeSetting(this, "modules.settings.world_time.preset");
    private final ModeSetting.Value custom = new ModeSetting.Value(this.preset, "Custom").select();
    private final ModeSetting.Value dawn = new ModeSetting.Value(this.preset, "Dawn");
    private final ModeSetting.Value noon = new ModeSetting.Value(this.preset, "Noon");
    private final ModeSetting.Value sunset = new ModeSetting.Value(this.preset, "Sunset");
    private final ModeSetting.Value midnight = new ModeSetting.Value(this.preset, "Midnight");

    private final SliderSetting customTime = new SliderSetting(this, "modules.settings.world_time.time",
            () -> !custom.isSelected())
            .min(0.0F).max(24000.0F).step(100.0F).currentValue(6000.0F);

    private final BooleanSetting freezeTime = new BooleanSetting(this, "modules.settings.world_time.freeze").enable();

    private long oldTime = -1;

    private final EventListener<ReceivePacketEvent> onPacket = event -> {
        if (freezeTime.isEnabled() && event.getPacket() instanceof WorldTimeUpdateS2CPacket) {
            event.cancel();
        }
    };

    @Override
    public void tick() {
        if (mc.world == null) return;
        mc.world.getLevelProperties().setTimeOfDay(getTargetTime());
        super.tick();
    }

    private long getTargetTime() {
        if (dawn.isSelected()) return 23000L;
        if (noon.isSelected()) return 6000L;
        if (sunset.isSelected()) return 12000L;
        if (midnight.isSelected()) return 18000L;
        return (long) customTime.getCurrentValue();
    }

    @Override
    public void onEnable() {
        if (mc.world != null) oldTime = mc.world.getTime();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (mc.world != null && oldTime >= 0) {
            mc.world.getLevelProperties().setTimeOfDay(oldTime);
        }
        oldTime = -1;
        super.onDisable();
    }
}
