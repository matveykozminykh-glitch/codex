package moscow.rockstar.systems.modules.modules.visuals;

import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import moscow.rockstar.Rockstar;
import moscow.rockstar.systems.event.EventListener;
import moscow.rockstar.systems.event.impl.render.Render3DEvent;
import moscow.rockstar.systems.modules.api.ModuleCategory;
import moscow.rockstar.systems.modules.api.ModuleInfo;
import moscow.rockstar.systems.modules.impl.BaseModule;
import moscow.rockstar.systems.setting.settings.BooleanSetting;
import moscow.rockstar.systems.setting.settings.ColorSetting;
import moscow.rockstar.systems.setting.settings.ModeSetting;
import moscow.rockstar.systems.setting.settings.SliderSetting;
import moscow.rockstar.utility.animation.base.Animation;
import moscow.rockstar.utility.animation.base.Easing;
import moscow.rockstar.utility.colors.ColorRGBA;
import moscow.rockstar.utility.colors.Colors;
import moscow.rockstar.utility.render.CrystalRenderer;
import moscow.rockstar.utility.render.DrawUtility;
import moscow.rockstar.utility.render.RenderUtility;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@ModuleInfo(name = "Custom Crystals", category = ModuleCategory.VISUALS, desc = "Кастомный рендер End кристаллов")
public class CustomCrystals extends BaseModule {

    private final ModeSetting style = new ModeSetting(this, "modules.settings.custom_crystals.style");
    private final ModeSetting.Value crystal = new ModeSetting.Value(this.style, "Crystal").select();
    private final ModeSetting.Value bloom = new ModeSetting.Value(this.style, "Bloom");
    private final ModeSetting.Value both = new ModeSetting.Value(this.style, "Both");

    private final ColorSetting crystalColor = new ColorSetting(this, "modules.settings.custom_crystals.color")
            .color(Colors.ACCENT);
    private final SliderSetting crystalSize = new SliderSetting(this, "modules.settings.custom_crystals.size")
            .min(0.1F).max(2.0F).step(0.05F).currentValue(0.6F);
    private final SliderSetting glowSize = new SliderSetting(this, "modules.settings.custom_crystals.glow_size")
            .min(0.1F).max(3.0F).step(0.05F).currentValue(1.0F);
    private final SliderSetting rotateSpeed = new SliderSetting(this, "modules.settings.custom_crystals.rotate_speed")
            .min(0.0F).max(5.0F).step(0.1F).currentValue(1.5F);
    private final SliderSetting bobSpeed = new SliderSetting(this, "modules.settings.custom_crystals.bob_speed")
            .min(0.0F).max(5.0F).step(0.1F).currentValue(1.0F);
    private final SliderSetting bobHeight = new SliderSetting(this, "modules.settings.custom_crystals.bob_height")
            .min(0.0F).max(1.0F).step(0.01F).currentValue(0.2F);
    private final BooleanSetting pulseGlow = new BooleanSetting(this, "modules.settings.custom_crystals.pulse").enable();
    private final BooleanSetting hideVanilla = new BooleanSetting(this, "modules.settings.custom_crystals.hide_vanilla").enable();

    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (mc.world == null) return;

        MatrixStack matrices = event.getMatrices();
        Camera camera = event.getCamera();
        long time = System.currentTimeMillis();
        ColorRGBA color = crystalColor.getColor();

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);

        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof EndCrystalEntity endCrystal)) continue;

            float tickDelta = mc.getRenderTickCounter().getTickDelta(false);
            float age = (endCrystal.endCrystalAge + tickDelta) * 0.1F;
            double y = endCrystal.getY() + MathHelper.sin(age * bobSpeed.getCurrentValue()) * bobHeight.getCurrentValue();
            float rotation = age * rotateSpeed.getCurrentValue() * 360.0F;

            Vec3d pos = new Vec3d(endCrystal.getX(), y, endCrystal.getZ());

            // Draw bloom glow
            if (bloom.isSelected() || both.isSelected()) {
                Identifier glowTex = Rockstar.id("textures/bloom.png");
                RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
                RenderSystem.setShaderTexture(0, glowTex);
                BufferBuilder glowBuilder = RenderSystem.renderThreadTesselator().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

                float gAlpha = pulseGlow.isEnabled()
                        ? 0.6F + 0.4F * MathHelper.sin((float)(time * 0.003))
                        : 0.8F;
                float gSize = glowSize.getCurrentValue();
                ColorRGBA glowColor = color.withAlpha(color.getAlpha() * gAlpha * 0.7F);

                matrices.push();
                RenderUtility.prepareMatrices(matrices, pos.add(0, 0.5, 0));
                matrices.multiply(camera.getRotation());
                DrawUtility.drawImage(matrices, glowBuilder, -gSize / 2.0, -gSize / 2.0, 0.0, gSize, gSize, glowColor);
                matrices.pop();
                RenderUtility.buildBuffer(glowBuilder);
            }

            // Draw crystal shape
            if (crystal.isSelected() || both.isSelected()) {
                float size = crystalSize.getCurrentValue();
                float crystalAlpha = pulseGlow.isEnabled()
                        ? 0.7F + 0.3F * MathHelper.sin((float)(time * 0.002))
                        : 0.85F;
                ColorRGBA crystalCol = color.withAlpha(color.getAlpha() * crystalAlpha);

                matrices.push();
                RenderUtility.prepareMatrices(matrices, pos.add(0, size * 0.5, 0));
                matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees(rotation));
                BufferBuilder crystalBuilder = CrystalRenderer.createBuffer();
                CrystalRenderer.render(matrices, crystalBuilder, 0.0F, 0.0F, 0.0F, size, crystalCol);
                BufferRenderer.drawWithGlobalProgram(crystalBuilder.end());
                matrices.pop();

                // Inner smaller crystal rotated oppositely
                matrices.push();
                RenderUtility.prepareMatrices(matrices, pos.add(0, size * 0.5, 0));
                matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees(-rotation * 1.5F));
                BufferBuilder inner = CrystalRenderer.createBuffer();
                CrystalRenderer.render(matrices, inner, 0.0F, 0.0F, 0.0F, size * 0.5F, crystalCol.withAlpha(crystalCol.getAlpha() * 0.6F));
                BufferRenderer.drawWithGlobalProgram(inner.end());
                matrices.pop();
            }
        }

        RenderSystem.depthMask(true);
        RenderSystem.setShaderTexture(0, 0);
        RenderSystem.disableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
    };

    public static boolean shouldHideVanilla() {
        CustomCrystals m = Rockstar.getInstance().getModuleManager().getModule(CustomCrystals.class);
        return m.isEnabled() && m.hideVanilla.isEnabled();
    }
}
