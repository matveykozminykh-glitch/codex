package moscow.rockstar.systems.modules.modules.visuals;

import moscow.rockstar.systems.event.EventListener;
import moscow.rockstar.systems.event.impl.network.ReceivePacketEvent;
import moscow.rockstar.systems.modules.api.ModuleCategory;
import moscow.rockstar.systems.modules.api.ModuleInfo;
import moscow.rockstar.systems.modules.impl.BaseModule;
import moscow.rockstar.systems.setting.settings.BooleanSetting;
import moscow.rockstar.systems.setting.settings.ColorSetting;
import moscow.rockstar.systems.setting.settings.ModeSetting;
import moscow.rockstar.systems.setting.settings.SliderSetting;
import moscow.rockstar.utility.colors.ColorRGBA;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;

@ModuleInfo(name = "Sky Color", category = ModuleCategory.VISUALS, desc = "Кастомный цвет неба в Overworld/Nether/End")
public class SkyColor extends BaseModule {

    private final ModeSetting dimension = new ModeSetting(this, "modules.settings.sky_color.dimension");
    private final ModeSetting.Value overworld = new ModeSetting.Value(this.dimension, "Overworld").select();
    private final ModeSetting.Value nether = new ModeSetting.Value(this.dimension, "Nether");
    private final ModeSetting.Value end = new ModeSetting.Value(this.dimension, "End");
    private final ModeSetting.Value all = new ModeSetting.Value(this.dimension, "All");

    private final ColorSetting skyColorTop = new ColorSetting(this, "modules.settings.sky_color.top")
            .color(new ColorRGBA(30, 10, 60, 255));
    private final ColorSetting skyColorHorizon = new ColorSetting(this, "modules.settings.sky_color.horizon")
            .color(new ColorRGBA(60, 20, 120, 255));

    private final BooleanSetting customTime = new BooleanSetting(this, "modules.settings.sky_color.custom_time");
    private final SliderSetting timeOfDay = new SliderSetting(this, "modules.settings.sky_color.time",
            () -> !customTime.isEnabled())
            .min(0.0F).max(24000.0F).step(100.0F).currentValue(6000.0F);

    private final BooleanSetting noWeather = new BooleanSetting(this, "modules.settings.sky_color.no_weather");

    private long oldTime = -1;

    private final EventListener<ReceivePacketEvent> onReceivePacket = event -> {
        if (event.getPacket() instanceof WorldTimeUpdateS2CPacket && customTime.isEnabled()) {
            event.cancel();
        }
    };

    @Override
    public void tick() {
        if (mc.world == null) return;

        if (customTime.isEnabled()) {
            mc.world.getLevelProperties().setTimeOfDay((long) timeOfDay.getCurrentValue());
        }

        if (noWeather.isEnabled()) {
            mc.world.setRainGradient(0.0F);
            mc.world.setThunderGradient(0.0F);
        }

        super.tick();
    }

    @Override
    public void onEnable() {
        if (mc.world != null) {
            oldTime = mc.world.getTime();
        }
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (mc.world != null && oldTime >= 0) {
            mc.world.getLevelProperties().setTimeOfDay(oldTime);
            mc.world.setRainGradient(0.0F);
        }
        oldTime = -1;
        super.onDisable();
    }

    public boolean shouldApply() {
        if (!isEnabled() || mc.world == null) return false;
        if (all.isSelected()) return true;
        String dimId = mc.world.getDimensionEntry().getIdAsString();
        if (overworld.isSelected()) return dimId.contains("overworld");
        if (nether.isSelected()) return dimId.contains("nether");
        if (end.isSelected()) return dimId.contains("end");
        return false;
    }

    public ColorRGBA getSkyTopColor() { return skyColorTop.getColor(); }
    public ColorRGBA getSkyHorizonColor() { return skyColorHorizon.getColor(); }
}
